import React from 'react';
import './summary.css';

const Summary = () => {
  return (
    <div className="summary-slide">
      <div className="background">
        <div className="summary">
          <div className='sum'>Sun</div>
          <div className='sum'>Mercury</div>
          <div className='sum'>Venus</div>
          <div className='sum'>Earth</div>
          <div className='sum'>Mars</div>
          <div className='sum'>Jupiter</div>
          <div className='sum'>Saturn</div>
          <div className='sum'>Uranus</div>
          <div className='sum'>Neptune</div>
        </div>
      </div>
    </div>
  );
};

export default Summary;
