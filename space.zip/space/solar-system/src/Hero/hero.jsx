import React from 'react';
import './hero.css';
import crackle from '../assets/crackle.png';
import righttop from '../assets/righttop.png';
import jupiterimg from '../assets/Jupiter.png';
import onto from '../assets/onto.png';
import rightbot from '../assets/rightbot.png';
import leftbot from '../assets/leftbot.png';
import left from '../assets/left.png';
import bottom from '../assets/bottom.png';
import topleft from '../assets/topleft.png';
import drop from '../assets/closef.png';

const Hero = ({ setClose, close }) => {

  const handleToggle = () => {
    setClose(!close);
    console.log(close);
  };

  return (
    <div className='hero-slide'>
      <div className="background">
        <div className="menu" onClick={handleToggle}>
          <div className="white"></div>
          <div className="white"></div>
          <div className="white"></div>
        </div>
        <img className='crackle' src={crackle} alt="crackle" />
        <img className='onto' src={onto} alt="onto" />
        <div className="headings">
          <div className="text">
            <img className='righttop' src={righttop} alt="right top" />
            <h1>Let's Get To Know Our Solar System Galaxy</h1>
            <p>
              Embark on a cosmic journey across the ethereal expanse of the solar system Galaxy and follow the orchestration of the cosmos and the planets weaving stories of their timeless existence.
              <br />
              <button className='buts'>Learn More</button>
            </p>
          </div>
        </div>
        <img className='rightbot' src={rightbot} alt="right bottom" />
        <img className='leftbot' src={leftbot} alt="left bottom" />
        <img className='left' src={left} alt="left" />
        <img className='bottom' src={bottom} alt="bottom" />
        <img src={topleft} className='topleft' alt="top left" />
      </div>
    </div>
  );
};

export default Hero;
